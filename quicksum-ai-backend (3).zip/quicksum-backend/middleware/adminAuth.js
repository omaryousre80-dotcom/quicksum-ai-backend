// middleware/adminAuth.js
// Deliberately simple: a single shared secret (ADMIN_KEY) checked against a
// header. There's no multi-admin/roles system yet — this is meant for one
// owner running a private, invite-only pilot. Upgrade to a real admin user
// role in the database once you have more than one person approving requests.

function requireAdmin(req, res, next) {
  const configuredKey = process.env.ADMIN_KEY;
  if (!configuredKey) {
    return res.status(503).json({
      error: 'لوحة الإدارة مش مفعّلة — حط قيمة ADMIN_KEY في متغيرات البيئة الأول',
    });
  }

  const providedKey = req.headers['x-admin-key'];
  if (!providedKey || providedKey !== configuredKey) {
    return res.status(401).json({ error: 'مفتاح الإدارة غير صحيح' });
  }

  next();
}

module.exports = { requireAdmin };
