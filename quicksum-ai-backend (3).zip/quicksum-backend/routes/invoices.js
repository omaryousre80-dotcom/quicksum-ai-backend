// routes/invoices.js
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');
const { scanLimiter } = require('../middleware/rateLimiters');
const { extractInvoiceData } = require('../lib/aiExtract');

const router = express.Router();

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('الملف المرفوع لازم يكون صورة'));
    }
    cb(null, true);
  },
});

function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

// POST /api/invoices/scan
// multipart/form-data: image=<file>, doc_type=invoice|pricelist|statement
router.post('/scan', requireAuth, scanLimiter, upload.single('image'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'محتاج صورة (image) في الطلب' });
  }
  const docType = req.body.doc_type || 'invoice';

  // Persist the uploaded image to disk so it can be referenced later.
  const filename = `${Date.now()}_${req.userId}${path.extname(req.file.originalname) || '.jpg'}`;
  const filepath = path.join(UPLOAD_DIR, filename);
  fs.writeFileSync(filepath, req.file.buffer);

  try {
    const extracted = await extractInvoiceData(req.file.buffer, req.file.mimetype);

    const lineItems = Array.isArray(extracted.line_items) ? extracted.line_items : [];
    const computedSubtotal = round2(
      lineItems.reduce((sum, item) => sum + (Number(item.line_total) || 0), 0)
    );

    res.json({
      image_url: `/uploads/${filename}`,
      doc_type: docType,
      ai: {
        warning: extracted.warning || null,
        fallback: !!extracted.fallback,
      },
      party_name: extracted.vendor_or_customer_name || null,
      invoice_number: extracted.invoice_number || null,
      date: extracted.date || null,
      currency: extracted.currency || 'EGP',
      tax_rate_percent: extracted.tax_rate_percent ?? null,
      detected_total: extracted.detected_total ?? null,
      computed_subtotal: computedSubtotal,
      line_items: lineItems.map((item) => ({
        name: item.name || '',
        quantity: Number(item.quantity) || 1,
        unit_price: round2(item.unit_price),
        line_total: round2(item.line_total),
        confidence: typeof item.confidence === 'number' ? item.confidence : 0.9,
      })),
    });
  } catch (err) {
    res.status(502).json({ error: 'فشلت عملية القراءة بالذكاء الاصطناعي: ' + err.message });
  }
});

// POST /api/invoices
// Save a (possibly user-edited) reviewed invoice.
router.post('/', requireAuth, (req, res) => {
  const {
    doc_type,
    party_name,
    party_type,
    invoice_number,
    date,
    currency,
    tax_rate_percent,
    discount_percent,
    line_items,
    image_url,
  } = req.body || {};

  if (!Array.isArray(line_items) || line_items.length === 0) {
    return res.status(400).json({ error: 'محتاج بند واحد على الأقل (line_items)' });
  }

  const subtotal = round2(line_items.reduce((s, it) => s + (Number(it.line_total) || 0), 0));
  const taxPct = Number(tax_rate_percent) || 0;
  const discPct = Number(discount_percent) || 0;
  const afterTax = subtotal * (1 + taxPct / 100);
  const finalTotal = round2(afterTax * (1 - discPct / 100));

  const invoice = db.invoices.create({
    user_id: req.userId,
    doc_type: doc_type || 'invoice',
    party_name: party_name || null,
    party_type: party_type || 'supplier',
    invoice_number: invoice_number || null,
    date: date || null,
    currency: currency || 'EGP',
    tax_rate_percent: taxPct,
    discount_percent: discPct,
    subtotal,
    final_total: finalTotal,
    image_url: image_url || null,
    line_items,
  });

  res.status(201).json({ invoice });
});

// GET /api/invoices  (history, newest first)
router.get('/', requireAuth, (req, res) => {
  res.json({ invoices: db.invoices.forUser(req.userId) });
});

// GET /api/invoices/:id
router.get('/:id', requireAuth, (req, res) => {
  const invoice = db.invoices.findById(Number(req.params.id), req.userId);
  if (!invoice) return res.status(404).json({ error: 'العملية غير موجودة' });
  res.json({ invoice });
});

// DELETE /api/invoices/:id
router.delete('/:id', requireAuth, (req, res) => {
  const removed = db.invoices.remove(Number(req.params.id), req.userId);
  if (!removed) return res.status(404).json({ error: 'العملية غير موجودة' });
  res.status(204).end();
});

// GET /api/invoices/stats/summary
router.get('/stats/summary', requireAuth, (req, res) => {
  const invoices = db.invoices.forUser(req.userId);
  const totalAmount = round2(invoices.reduce((s, inv) => s + (Number(inv.final_total) || 0), 0));
  const count = invoices.length;
  const avg = count > 0 ? round2(totalAmount / count) : 0;

  const bySupplier = {};
  invoices.forEach((inv) => {
    if (!inv.party_name) return;
    bySupplier[inv.party_name] = (bySupplier[inv.party_name] || 0) + 1;
  });
  const topParties = Object.entries(bySupplier)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([name, ops]) => ({ name, ops }));

  res.json({ count, total_amount: totalAmount, average_invoice: avg, top_parties: topParties });
});

module.exports = router;
