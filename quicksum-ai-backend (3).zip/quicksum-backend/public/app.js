const API = '/api';
let token = localStorage.getItem('qs_token') || null;
let currentScan = null; // holds the last /scan response while reviewing

/* ---------------- helpers ---------------- */
function authHeaders(extra) {
  return { Authorization: `Bearer ${token}`, ...(extra || {}) };
}
function showToast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => el.classList.remove('show'), 3000);
}
function fmt(n) {
  return (Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/* ---------------- auth view ---------------- */
let inviteOnly = false;

function setAuthTab(tab) {
  document.getElementById('tabLogin').classList.toggle('active', tab === 'login');
  document.getElementById('tabRegister').classList.toggle('active', tab === 'register');
  document.getElementById('loginForm').style.display = tab === 'login' ? 'block' : 'none';
  document.getElementById('registerForm').style.display = tab === 'register' && !inviteOnly ? 'block' : 'none';
  document.getElementById('joinRequestForm').style.display = tab === 'register' && inviteOnly ? 'block' : 'none';
  document.getElementById('forgotForm').style.display = 'none';
  document.getElementById('authMsg').textContent = '';
  document.getElementById('devNote').style.display = 'none';
}

async function doJoinRequest() {
  const name = document.getElementById('jrName').value.trim();
  const email = document.getElementById('jrEmail').value.trim();
  const phone = document.getElementById('jrPhone').value.trim();
  const business_name = document.getElementById('jrBusiness').value.trim();
  const message = document.getElementById('jrMessage').value.trim();
  if (!name || !email) return setAuthMsg('الاسم والبريد الإلكتروني مطلوبين', true);

  try {
    const res = await fetch(`${API}/join-requests`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name, email, phone, business_name, message }),
    });
    const data = await res.json();
    if (!res.ok) return setAuthMsg(data.error || 'حصل خطأ', true);
    setAuthMsg(data.message, false);
    ['jrName', 'jrEmail', 'jrPhone', 'jrBusiness', 'jrMessage'].forEach((id) => (document.getElementById(id).value = ''));
  } catch (e) {
    setAuthMsg('تعذّر الاتصال بالسيرفر: ' + e.message, true);
  }
}

function showForgotPassword() {
  document.getElementById('loginForm').style.display = 'none';
  document.getElementById('registerForm').style.display = 'none';
  document.getElementById('forgotForm').style.display = 'block';
  document.getElementById('authMsg').textContent = '';
  document.getElementById('devNote').style.display = 'none';
}

function setAuthMsg(msg, isError) {
  const el = document.getElementById('authMsg');
  el.textContent = msg;
  el.className = 'msg ' + (isError ? 'error' : 'ok');
}

function showDevNote(devObj, labelPrefix) {
  const el = document.getElementById('devNote');
  if (!devObj || !devObj.link) {
    el.style.display = 'none';
    return;
  }
  el.style.display = 'block';
  el.innerHTML = `🧪 <b>${labelPrefix}</b> (${devObj.note}):<br><a href="${devObj.link}" target="_blank">${devObj.link}</a>`;
}

async function doRegister() {
  const name = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value;
  if (!name || !email || !password) return setAuthMsg('املأ كل الحقول', true);

  try {
    const res = await fetch(`${API}/auth/register`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });
    const data = await res.json();
    if (!res.ok) return setAuthMsg(data.error || 'حصل خطأ', true);
    if (data.dev_verification) showDevNote(data.dev_verification, 'رابط تأكيد البريد');
    onAuthSuccess(data.token, data.user);
  } catch (e) {
    setAuthMsg('تعذّر الاتصال بالسيرفر: ' + e.message, true);
  }
}

async function doLogin() {
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  if (!email || !password) return setAuthMsg('املأ كل الحقول', true);

  try {
    const res = await fetch(`${API}/auth/login`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) return setAuthMsg(data.error || 'حصل خطأ', true);
    onAuthSuccess(data.token, data.user);
  } catch (e) {
    setAuthMsg('تعذّر الاتصال بالسيرفر: ' + e.message, true);
  }
}

async function doForgotPassword() {
  const email = document.getElementById('forgotEmail').value.trim();
  if (!email) return setAuthMsg('اكتب بريدك الإلكتروني', true);

  try {
    const res = await fetch(`${API}/auth/forgot-password`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    const data = await res.json();
    if (!res.ok) return setAuthMsg(data.error || 'حصل خطأ', true);
    setAuthMsg(data.message, false);
    if (data.dev_reset) showDevNote(data.dev_reset, 'رابط إعادة تعيين كلمة المرور');
  } catch (e) {
    setAuthMsg('تعذّر الاتصال بالسيرفر: ' + e.message, true);
  }
}

async function doResetPassword() {
  const params = new URLSearchParams(window.location.search);
  const resetToken = params.get('token');
  const newPassword = document.getElementById('newPassword').value;
  const msgEl = document.getElementById('resetMsg');

  if (!resetToken) {
    msgEl.className = 'msg error';
    msgEl.textContent = 'رابط غير صالح — التوكن مفقود';
    return;
  }
  if (!newPassword) {
    msgEl.className = 'msg error';
    msgEl.textContent = 'اكتب كلمة المرور الجديدة';
    return;
  }

  try {
    const res = await fetch(`${API}/auth/reset-password`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ token: resetToken, newPassword }),
    });
    const data = await res.json();
    msgEl.className = 'msg ' + (res.ok ? 'ok' : 'error');
    msgEl.textContent = data.message || data.error;
    if (res.ok) {
      setTimeout(() => (window.location.href = '/'), 1800);
    }
  } catch (e) {
    msgEl.className = 'msg error';
    msgEl.textContent = 'تعذّر الاتصال بالسيرفر: ' + e.message;
  }
}

async function resendVerification() {
  try {
    const res = await fetch(`${API}/auth/resend-verification`, {
      method: 'POST',
      headers: authHeaders(),
    });
    const data = await res.json();
    if (!res.ok) return showToast(data.error || 'حصل خطأ');
    showToast('اتبعت رابط تأكيد جديد ✓');
    if (data.dev_verification) {
      showToast('DEV: ' + data.dev_verification.link);
      console.log('Verification link (dev mode):', data.dev_verification.link);
    }
  } catch (e) {
    showToast('حصل خطأ: ' + e.message);
  }
}

/* ---------------- routing: verify-email / reset-password pages ---------------- */
async function handleSpecialRoutes() {
  const path = window.location.pathname;

  if (path === '/verify-email') {
    document.getElementById('authView').style.display = 'none';
    document.getElementById('appView').style.display = 'none';
    document.getElementById('verifyEmailView').style.display = 'block';
    const params = new URLSearchParams(window.location.search);
    const vToken = params.get('token');
    const titleEl = document.getElementById('verifyTitle');
    const subEl = document.getElementById('verifySub');
    const iconEl = document.getElementById('verifyIcon');
    if (!vToken) {
      iconEl.textContent = '⚠️';
      titleEl.textContent = 'رابط غير صالح';
      subEl.textContent = 'التوكن مفقود من الرابط';
      return true;
    }
    try {
      const res = await fetch(`${API}/auth/verify-email`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ token: vToken }),
      });
      const data = await res.json();
      if (res.ok) {
        iconEl.textContent = '✅';
        titleEl.textContent = 'تم تأكيد بريدك الإلكتروني بنجاح';
        subEl.textContent = 'تقدر دلوقتي تسجّل دخولك عادي';
      } else {
        iconEl.textContent = '⚠️';
        titleEl.textContent = 'تعذّر التأكيد';
        subEl.textContent = data.error || '';
      }
    } catch (e) {
      iconEl.textContent = '⚠️';
      titleEl.textContent = 'تعذّر الاتصال بالسيرفر';
      subEl.textContent = e.message;
    }
    return true;
  }

  if (path === '/reset-password') {
    document.getElementById('authView').style.display = 'none';
    document.getElementById('appView').style.display = 'none';
    document.getElementById('resetPasswordView').style.display = 'block';
    return true;
  }

  return false;
}

function onAuthSuccess(newToken, user) {
  token = newToken;
  localStorage.setItem('qs_token', token);
  document.getElementById('authView').style.display = 'none';
  document.getElementById('appView').style.display = 'block';
  document.getElementById('logoutBtn').style.display = 'inline-block';
  document.getElementById('verifyBanner').style.display = user.email_verified ? 'none' : 'flex';
  showToast(`أهلًا ${user.name} 👋`);
  loadStats();
  loadHistory();
}

function logout() {
  token = null;
  localStorage.removeItem('qs_token');
  document.getElementById('authView').style.display = 'block';
  document.getElementById('appView').style.display = 'none';
  document.getElementById('logoutBtn').style.display = 'none';
}

async function tryResumeSession() {
  if (!token) return;
  try {
    const res = await fetch(`${API}/auth/me`, { headers: authHeaders() });
    if (!res.ok) throw new Error('session expired');
    const data = await res.json();
    onAuthSuccess(token, data.user);
  } catch (e) {
    logout();
  }
}

/* ---------------- capture + scan ---------------- */
document.addEventListener('DOMContentLoaded', async () => {
  document.getElementById('cameraInput').addEventListener('change', (e) => handleFile(e.target.files[0]));
  document.getElementById('galleryInput').addEventListener('change', (e) => handleFile(e.target.files[0]));

  const handledSpecialRoute = await handleSpecialRoutes();
  if (!handledSpecialRoute) {
    tryResumeSession();
  }

  fetch(`${API}/health`)
    .then((r) => r.json())
    .then((h) => {
      if (!h.ai_configured) {
        document.getElementById('healthNote').textContent =
          '⚠️ ANTHROPIC_API_KEY مش مضبوط على السيرفر — القراءة هترجع بيانات تجريبية فقط';
      }
      inviteOnly = !!h.invite_only;
      if (inviteOnly) {
        document.getElementById('tabRegister').textContent = 'طلب انضمام';
      }
    })
    .catch(() => {});
});

async function handleFile(file) {
  if (!file || !token) return;
  document.getElementById('captureCard').style.display = 'none';
  document.getElementById('reviewSection').style.display = 'none';
  document.getElementById('scanProgress').style.display = 'block';
  document.getElementById('scanProgressLabel').textContent = 'جاري رفع الصورة وتحليلها بالذكاء الاصطناعي...';

  const form = new FormData();
  form.append('image', file);
  form.append('doc_type', 'invoice');

  try {
    const res = await fetch(`${API}/invoices/scan`, {
      method: 'POST',
      headers: authHeaders(),
      body: form,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'فشلت القراءة');
    currentScan = data;
    populateReview(data);
  } catch (e) {
    showToast('حصل خطأ: ' + e.message);
    document.getElementById('captureCard').style.display = 'flex';
  } finally {
    document.getElementById('scanProgress').style.display = 'none';
  }
}

function populateReview(data) {
  document.getElementById('reviewSection').style.display = 'block';
  const warnCard = document.getElementById('aiWarningCard');
  if (data.ai && data.ai.warning) {
    warnCard.style.display = 'block';
    warnCard.textContent = '⚠ ' + data.ai.warning;
  } else {
    warnCard.style.display = 'none';
  }
  document.getElementById('rvParty').value = data.party_name || '';
  document.getElementById('rvInvoiceNo').value = data.invoice_number || '';
  document.getElementById('rvDate').value = data.date || '';
  document.getElementById('rvCurrency').value = data.currency || 'EGP';
  document.getElementById('rvTax').value = data.tax_rate_percent || 0;
  document.getElementById('rvDiscount').value = 0;

  const list = document.getElementById('itemsList');
  list.innerHTML = '';
  (data.line_items || []).forEach((item) => addItemRow(item));
  if (!data.line_items || data.line_items.length === 0) {
    addItemRow(); // start with one empty row so the user can enter manually
  }
  recalcTotal();
}

function addItemRow(item) {
  const row = document.createElement('div');
  row.className = 'item-row';
  const conf = item && typeof item.confidence === 'number' ? item.confidence : 1;
  const confPct = Math.round(conf * 100);
  row.innerHTML = `
    <div class="top-line">
      <input class="name" placeholder="اسم البند" value="${item && item.name ? escapeHtml(item.name) : ''}">
      <span class="confidence ${confPct < 75 ? 'low' : ''}">${confPct}%</span>
      <span class="del" onclick="this.closest('.item-row').remove(); recalcTotal();">✕</span>
    </div>
    <div class="bottom-line">
      <span>كمية</span><input class="mono qty" value="${item && item.quantity !== undefined ? item.quantity : 1}" oninput="recalcRow(this)">
      <span>×</span>
      <span>سعر</span><input class="mono price" value="${item ? fmt(item.unit_price) : '0.00'}" oninput="recalcRow(this)">
      <span>=</span>
      <input class="mono total" value="${item ? fmt(item.line_total) : '0.00'}" oninput="recalcTotal()">
    </div>`;
  document.getElementById('itemsList').appendChild(row);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function recalcRow(el) {
  const row = el.closest('.item-row');
  const qty = parseFloat(row.querySelector('.qty').value) || 0;
  const price = parseFloat(row.querySelector('.price').value) || 0;
  row.querySelector('.total').value = fmt(qty * price);
  recalcTotal();
}

function recalcTotal() {
  const rows = document.querySelectorAll('#itemsList .item-row');
  let subtotal = 0;
  rows.forEach((r) => {
    subtotal += parseFloat(r.querySelector('.total').value) || 0;
  });
  const tax = parseFloat(document.getElementById('rvTax').value) || 0;
  const disc = parseFloat(document.getElementById('rvDiscount').value) || 0;
  const final = subtotal * (1 + tax / 100) * (1 - disc / 100);
  document.getElementById('finalTotalLabel').textContent = fmt(final);
}

function cancelReview() {
  currentScan = null;
  document.getElementById('reviewSection').style.display = 'none';
  document.getElementById('captureCard').style.display = 'flex';
  document.getElementById('cameraInput').value = '';
  document.getElementById('galleryInput').value = '';
}

async function saveInvoice() {
  const rows = document.querySelectorAll('#itemsList .item-row');
  const lineItems = Array.from(rows)
    .map((r) => ({
      name: r.querySelector('.name').value.trim(),
      quantity: parseFloat(r.querySelector('.qty').value) || 1,
      unit_price: parseFloat(r.querySelector('.price').value) || 0,
      line_total: parseFloat(r.querySelector('.total').value) || 0,
    }))
    .filter((it) => it.name || it.line_total > 0);

  if (lineItems.length === 0) {
    return showToast('ضيف بند واحد على الأقل قبل الحفظ');
  }

  const payload = {
    doc_type: (currentScan && currentScan.doc_type) || 'invoice',
    party_name: document.getElementById('rvParty').value.trim() || null,
    party_type: 'supplier',
    invoice_number: document.getElementById('rvInvoiceNo').value.trim() || null,
    date: document.getElementById('rvDate').value.trim() || null,
    currency: document.getElementById('rvCurrency').value,
    tax_rate_percent: parseFloat(document.getElementById('rvTax').value) || 0,
    discount_percent: parseFloat(document.getElementById('rvDiscount').value) || 0,
    line_items: lineItems,
    image_url: currentScan ? currentScan.image_url : null,
  };

  try {
    const res = await fetch(`${API}/invoices`, {
      method: 'POST',
      headers: authHeaders({ 'content-type': 'application/json' }),
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'فشل الحفظ');
    showToast('اتحفظت العملية في السجل ✓');
    cancelReview();
    loadStats();
    loadHistory();
  } catch (e) {
    showToast('حصل خطأ أثناء الحفظ: ' + e.message);
  }
}

/* ---------------- history + stats ---------------- */
async function loadHistory() {
  try {
    const res = await fetch(`${API}/invoices`, { headers: authHeaders() });
    const data = await res.json();
    const list = document.getElementById('historyList');
    const empty = document.getElementById('historyEmpty');
    list.innerHTML = '';
    if (!data.invoices || data.invoices.length === 0) {
      empty.style.display = 'block';
      return;
    }
    empty.style.display = 'none';
    data.invoices.forEach((inv) => {
      const row = document.createElement('div');
      row.className = 'hist-row';
      const dateLabel = inv.date || new Date(inv.created_at).toLocaleDateString('ar-EG');
      row.innerHTML = `
        <div class="info">
          <div class="t">${escapeHtml(inv.party_name || 'بدون اسم')}</div>
          <div class="s">${escapeHtml(dateLabel)} · ${(inv.line_items || []).length} بند${inv.invoice_number ? ' · ' + escapeHtml(inv.invoice_number) : ''}</div>
        </div>
        <div class="amt">${fmt(inv.final_total)}</div>
        <span class="del" onclick="deleteInvoice(${inv.id})">✕</span>`;
      list.appendChild(row);
    });
  } catch (e) {
    showToast('تعذّر تحميل السجل: ' + e.message);
  }
}

async function deleteInvoice(id) {
  try {
    const res = await fetch(`${API}/invoices/${id}`, { method: 'DELETE', headers: authHeaders() });
    if (!res.ok && res.status !== 204) throw new Error('فشل الحذف');
    loadStats();
    loadHistory();
  } catch (e) {
    showToast('حصل خطأ: ' + e.message);
  }
}

async function loadStats() {
  try {
    const res = await fetch(`${API}/invoices/stats/summary`, { headers: authHeaders() });
    const data = await res.json();
    document.getElementById('statCount').textContent = data.count;
    document.getElementById('statTotal').textContent = fmt(data.total_amount);
    document.getElementById('statAvg').textContent = fmt(data.average_invoice);
  } catch (e) {
    /* non-fatal */
  }
}
