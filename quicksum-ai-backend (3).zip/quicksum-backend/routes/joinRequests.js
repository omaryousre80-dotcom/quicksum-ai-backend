// routes/joinRequests.js
const express = require('express');
const db = require('../db');
const { requireAdmin } = require('../middleware/adminAuth');
const { forgotPasswordLimiter } = require('../middleware/rateLimiters');
const { generateToken, hashToken } = require('../lib/tokens');
const { sendEmail } = require('../lib/email');

const router = express.Router();

const APP_URL = process.env.APP_URL || 'http://localhost:3000';
const SET_PASSWORD_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days — give people time to see the email

function isValidEmail(email) {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// POST /api/join-requests  (public)
// { name, email, phone, business_name, message }
router.post('/join-requests', forgotPasswordLimiter, (req, res) => {
  const { name, email, phone, business_name, message } = req.body || {};

  if (!name || !email) {
    return res.status(400).json({ error: 'الاسم والبريد الإلكتروني مطلوبين' });
  }
  if (!isValidEmail(email)) {
    return res.status(400).json({ error: 'صيغة البريد الإلكتروني غير صحيحة' });
  }
  if (db.users.findByEmail(email)) {
    return res.status(409).json({ error: 'في حساب مفعّل بالفعل بالبريد الإلكتروني ده' });
  }
  if (db.joinRequests.findPendingByEmail(email)) {
    return res.status(409).json({ error: 'في طلب انضمام قيد المراجعة بالفعل بنفس البريد الإلكتروني' });
  }

  const request = db.joinRequests.create({
    name,
    email,
    phone: phone || null,
    business_name: business_name || null,
    message: message || null,
  });

  res.status(201).json({
    ok: true,
    message: 'تم استلام طلبك، هيتم مراجعته والتواصل معاك على البريد الإلكتروني قريبًا',
    request_id: request.id,
  });
});

// GET /api/admin/join-requests?status=pending|approved|rejected  (admin)
router.get('/admin/join-requests', requireAdmin, (req, res) => {
  const status = req.query.status;
  let requests = db.joinRequests.all();
  if (status) requests = requests.filter((r) => r.status === status);
  res.json({ requests });
});

// POST /api/admin/join-requests/:id/approve  (admin)
router.post('/admin/join-requests/:id/approve', requireAdmin, async (req, res) => {
  const request = db.joinRequests.findById(Number(req.params.id));
  if (!request) return res.status(404).json({ error: 'الطلب غير موجود' });
  if (request.status !== 'pending') {
    return res.status(400).json({ error: `الطلب اتعالج بالفعل (${request.status})` });
  }
  if (db.users.findByEmail(request.email)) {
    db.joinRequests.update(request.id, { status: 'approved' });
    return res.status(409).json({ error: 'في حساب بالفعل بالبريد ده — اتحدثت حالة الطلب' });
  }

  // Create the account with a random unusable password hash — the user sets
  // their real password via the same set-password/reset-password link+flow.
  const crypto = require('crypto');
  const user = db.users.create({
    name: request.name,
    email: request.email,
    phone: request.phone || null,
    password_hash: crypto.randomBytes(32).toString('hex'), // unusable placeholder, never given out
    language: 'ar',
    currency: 'EGP',
    plan: 'free',
    email_verified: true, // manually vetted by the admin, so treat as verified
  });

  const { raw, hash } = generateToken();
  db.users.update(user.id, {
    password_reset_token_hash: hash,
    password_reset_expires: Date.now() + SET_PASSWORD_TTL_MS,
  });

  const link = `${APP_URL}/reset-password?token=${raw}`;
  let devInfo = null;
  try {
    const result = await sendEmail({
      to: user.email,
      subject: 'اتقبلت طلب انضمامك — QuickSum AI',
      text: `أهلًا ${user.name}، اتقبل طلبك للانضمام إلى QuickSum AI. عيّن كلمة مرورك من الرابط ده (صالح 7 أيام): ${link}`,
    });
    if (result.devMode) devInfo = { note: 'SMTP غير مضبوط — رابط تجريبي', link };
  } catch (e) {
    console.error('Failed to send approval email:', e.message);
  }

  db.joinRequests.update(request.id, { status: 'approved', user_id: user.id });
  res.json({ ok: true, user_id: user.id, dev_set_password: devInfo });
});

// POST /api/admin/join-requests/:id/reject  (admin)
router.post('/admin/join-requests/:id/reject', requireAdmin, (req, res) => {
  const request = db.joinRequests.findById(Number(req.params.id));
  if (!request) return res.status(404).json({ error: 'الطلب غير موجود' });
  if (request.status !== 'pending') {
    return res.status(400).json({ error: `الطلب اتعالج بالفعل (${request.status})` });
  }
  db.joinRequests.update(request.id, { status: 'rejected' });
  res.json({ ok: true });
});

module.exports = router;
