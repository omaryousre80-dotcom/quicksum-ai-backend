// middleware/rateLimiters.js
const rateLimit = require('express-rate-limit');

// Generic response shape matching the rest of the API (Arabic error message).
function limitHandler(req, res) {
  res.status(429).json({
    error: 'محاولات كتير في وقت قصير — استنى شوية وحاول تاني',
  });
}

// Login/register: prevent credential-stuffing / brute force.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  handler: limitHandler,
});

// Forgot-password: stricter, since it also triggers an email send.
const forgotPasswordLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  handler: limitHandler,
});

// AI scan endpoint: real (costed) API calls — cap abuse regardless of plan limits.
const scanLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  handler: limitHandler,
});

module.exports = { authLimiter, forgotPasswordLimiter, scanLimiter };
