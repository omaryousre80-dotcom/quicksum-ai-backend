// routes/auth.js
const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { requireAuth, signToken } = require('../middleware/auth');
const { authLimiter, forgotPasswordLimiter } = require('../middleware/rateLimiters');
const { generateToken, hashToken } = require('../lib/tokens');
const { sendEmail } = require('../lib/email');

const router = express.Router();

const APP_URL = process.env.APP_URL || 'http://localhost:3000';
const VERIFY_TOKEN_TTL_MS = 24 * 60 * 60 * 1000; // 24h
const RESET_TOKEN_TTL_MS = 60 * 60 * 1000; // 1h

function isValidEmail(email) {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// At least 8 chars, at least one letter and one number.
function isStrongEnoughPassword(password) {
  return (
    typeof password === 'string' &&
    password.length >= 8 &&
    /[A-Za-z]/.test(password) &&
    /[0-9]/.test(password)
  );
}

function publicUser(user) {
  const { password_hash, email_verify_token_hash, password_reset_token_hash, ...rest } = user;
  return rest;
}

async function sendVerificationEmail(user) {
  const { raw, hash } = generateToken();
  db.users.update(user.id, {
    email_verify_token_hash: hash,
    email_verify_expires: Date.now() + VERIFY_TOKEN_TTL_MS,
  });
  const link = `${APP_URL}/verify-email?token=${raw}`;
  const result = await sendEmail({
    to: user.email,
    subject: 'أكّد بريدك الإلكتروني — QuickSum AI',
    text: `أهلًا ${user.name}، أكّد بريدك الإلكتروني من الرابط ده: ${link} (صالح لمدة 24 ساعة)`,
  });
  return { link, devMode: result.devMode };
}

// POST /api/auth/register
router.post('/register', authLimiter, async (req, res) => {
  if (process.env.INVITE_ONLY === 'true') {
    return res.status(403).json({
      error: 'التسجيل المباشر مقفول حاليًا — قدّم طلب انضمام من /api/join-requests وهيتم التواصل معاك',
      invite_only: true,
    });
  }

  const { name, email, password, phone } = req.body || {};

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'الاسم والبريد الإلكتروني وكلمة المرور مطلوبين' });
  }
  if (!isValidEmail(email)) {
    return res.status(400).json({ error: 'صيغة البريد الإلكتروني غير صحيحة' });
  }
  if (!isStrongEnoughPassword(password)) {
    return res
      .status(400)
      .json({ error: 'كلمة المرور لازم تكون 8 أحرف على الأقل وتحتوي على حرف ورقم' });
  }
  if (db.users.findByEmail(email)) {
    return res.status(409).json({ error: 'في حساب مسجل بالبريد الإلكتروني ده بالفعل' });
  }

  const password_hash = await bcrypt.hash(password, 10);
  const user = db.users.create({
    name,
    email,
    phone: phone || null,
    password_hash,
    language: 'ar',
    currency: 'EGP',
    plan: 'free',
    email_verified: false,
  });

  const token = signToken(user.id);

  let devVerification = null;
  try {
    const { link, devMode } = await sendVerificationEmail(user);
    if (devMode) devVerification = { note: 'SMTP غير مضبوط — ده رابط التأكيد لأغراض التجربة فقط', link };
  } catch (e) {
    console.error('Failed to send verification email:', e.message);
  }

  res.status(201).json({
    token,
    user: publicUser(db.users.findById(user.id)),
    dev_verification: devVerification,
  });
});

// POST /api/auth/login
router.post('/login', authLimiter, async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'البريد الإلكتروني وكلمة المرور مطلوبين' });
  }

  const user = db.users.findByEmail(email);
  if (!user) {
    return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
  }

  const match = await bcrypt.compare(password, user.password_hash);
  if (!match) {
    return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
  }

  const token = signToken(user.id);
  res.json({ token, user: publicUser(user) });
});

// GET /api/auth/me  (requires auth)
router.get('/me', requireAuth, (req, res) => {
  const user = db.users.findById(req.userId);
  if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });
  res.json({ user: publicUser(user) });
});

// PATCH /api/auth/me  (update language/currency/name)
router.patch('/me', requireAuth, (req, res) => {
  const allowed = ['name', 'language', 'currency'];
  const patch = {};
  for (const key of allowed) {
    if (req.body[key] !== undefined) patch[key] = req.body[key];
  }
  const user = db.users.update(req.userId, patch);
  if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });
  res.json({ user: publicUser(user) });
});

// POST /api/auth/verify-email  { token }
router.post('/verify-email', (req, res) => {
  const { token } = req.body || {};
  if (!token) return res.status(400).json({ error: 'التوكن مطلوب' });

  const hash = hashToken(token);
  const user = db.users.all().find((u) => u.email_verify_token_hash === hash);

  if (!user) {
    return res.status(400).json({ error: 'رابط التأكيد غير صحيح' });
  }
  if (!user.email_verify_expires || Date.now() > user.email_verify_expires) {
    return res.status(400).json({ error: 'رابط التأكيد منتهي — اطلب رابط جديد' });
  }

  db.users.update(user.id, {
    email_verified: true,
    email_verify_token_hash: null,
    email_verify_expires: null,
  });

  res.json({ ok: true, message: 'تم تأكيد البريد الإلكتروني بنجاح' });
});

// POST /api/auth/resend-verification  (requires auth)
router.post('/resend-verification', requireAuth, authLimiter, async (req, res) => {
  const user = db.users.findById(req.userId);
  if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });
  if (user.email_verified) {
    return res.status(400).json({ error: 'البريد الإلكتروني متأكد بالفعل' });
  }

  try {
    const { link, devMode } = await sendVerificationEmail(user);
    res.json({
      ok: true,
      dev_verification: devMode ? { note: 'SMTP غير مضبوط — رابط تجريبي', link } : null,
    });
  } catch (e) {
    res.status(502).json({ error: 'فشل إرسال بريد التأكيد: ' + e.message });
  }
});

// POST /api/auth/forgot-password  { email }
// Always returns a generic success response — never reveals whether the
// email exists, to avoid leaking which addresses are registered.
router.post('/forgot-password', forgotPasswordLimiter, async (req, res) => {
  const { email } = req.body || {};
  if (!email || !isValidEmail(email)) {
    return res.status(400).json({ error: 'البريد الإلكتروني مطلوب وصحيح' });
  }

  const genericResponse = {
    ok: true,
    message: 'لو البريد الإلكتروني ده مسجل عندنا، هيوصله رابط إعادة تعيين كلمة المرور',
  };

  const user = db.users.findByEmail(email);
  if (!user) {
    // Same response either way — don't leak account existence.
    return res.json(genericResponse);
  }

  const { raw, hash } = generateToken();
  db.users.update(user.id, {
    password_reset_token_hash: hash,
    password_reset_expires: Date.now() + RESET_TOKEN_TTL_MS,
  });

  const link = `${APP_URL}/reset-password?token=${raw}`;
  try {
    const result = await sendEmail({
      to: user.email,
      subject: 'إعادة تعيين كلمة المرور — QuickSum AI',
      text: `اضغط الرابط ده عشان تعيد تعيين كلمة المرور (صالح لمدة ساعة): ${link}\nلو انت مش اللي طلبت ده، تجاهل الرسالة.`,
    });
    if (result.devMode) {
      genericResponse.dev_reset = { note: 'SMTP غير مضبوط — رابط تجريبي', link };
    }
  } catch (e) {
    console.error('Failed to send reset email:', e.message);
  }

  res.json(genericResponse);
});

// POST /api/auth/reset-password  { token, newPassword }
router.post('/reset-password', forgotPasswordLimiter, async (req, res) => {
  const { token, newPassword } = req.body || {};
  if (!token || !newPassword) {
    return res.status(400).json({ error: 'التوكن وكلمة المرور الجديدة مطلوبين' });
  }
  if (!isStrongEnoughPassword(newPassword)) {
    return res
      .status(400)
      .json({ error: 'كلمة المرور لازم تكون 8 أحرف على الأقل وتحتوي على حرف ورقم' });
  }

  const hash = hashToken(token);
  const user = db.users.all().find((u) => u.password_reset_token_hash === hash);

  if (!user) {
    return res.status(400).json({ error: 'رابط إعادة التعيين غير صحيح' });
  }
  if (!user.password_reset_expires || Date.now() > user.password_reset_expires) {
    return res.status(400).json({ error: 'رابط إعادة التعيين منتهي — اطلب رابط جديد' });
  }

  const password_hash = await bcrypt.hash(newPassword, 10);
  db.users.update(user.id, {
    password_hash,
    password_reset_token_hash: null,
    password_reset_expires: null,
  });

  res.json({ ok: true, message: 'تم تغيير كلمة المرور بنجاح — سجّل دخول بالكلمة الجديدة' });
});

module.exports = router;
